from dataclasses import dataclass
import numpy as np
import meshio

@dataclass
class Triangulation:
    """
    Hier sollte Ihre Klassendefinition stehen. Achten Sie darauf, dass Ihre 
    Klasse tatsächlich den angegebenen Namen "Triangulation" hat!
    """

    # Hier steht Ihr Code




def read_msh(filename):
    """
    Lese msh-File ein, lese alle notwendigen Daten aus und erstelle daraus eine
    Instanz der selbst definierten Klasse 'Triangulation'
    
    Parameters
    ----------
    filename : str
        filename der msh-Datei, in der die Triangulierung gespeichert ist.

    Returns
    -------
    Triangulierung
        Triangulierung als Instanz der selbst definierten Klasse 
        'Triangulierung'
    """
    
    # Endung .msh ergänzen, falls noch nicht der Fall
    if not filename.endswith('.msh'):
        filename += '.msh'
        
    mesh = meshio.read(filename)
    
    # relevante Daten auslesen:
    
    # 1.) Punkteliste mit Koordinaten aller Punkte
    points_3d = mesh.points
    points = points_3d[:, :2]
    
    # 2.) Dreiecksliste
    triangles = mesh.cells_dict['triangle']
    
    # 3.) Dirichlet-Rand-Kanten
    if 'DirichletRand' in mesh.field_data: # Checke, ob entsprechender Key existiert
        dir_tag = mesh.field_data['DirichletRand'][0]
        edge_dir_YN = ( mesh.cell_data_dict['gmsh:physical']['line'] == dir_tag )
        edges_dir = mesh.cells_dict['line'][edge_dir_YN]
    else:
        edges_dir = np.zeros([0, 2], dtype=int) 
    
    # 4.) Neumann-Rand-Kanten
    if 'NeumannRand' in mesh.field_data: # Checke, ob entsprechender Key existiert
        neu_tag = mesh.field_data['NeumannRand'][0]
        edge_neu_YN = ( mesh.cell_data_dict['gmsh:physical']['line'] == neu_tag )
        edges_neu = mesh.cells_dict['line'][edge_neu_YN]
    else:
        edges_neu = np.zeros([0, 2], dtype=int)
    
    return Triangulation(points, triangles, edges_dir, edges_neu)

